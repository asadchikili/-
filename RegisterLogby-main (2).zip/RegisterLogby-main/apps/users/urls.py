from django.urls import path
from apps.users import views as users
from django.contrib.auth.views import LoginView

urlpatterns = [
    path('', users.index, name="index"),
    path('/register/', users.register, name="register"),
    path('/user_login/', users.user_login,name="user_login"),
    path("/profile/<int:id>/",users.profile,name="profile"),
    path("/logout/",LoginView.as_view(next_page="index",name="logout"))
]